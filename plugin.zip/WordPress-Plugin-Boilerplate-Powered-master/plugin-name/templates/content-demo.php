<!-- @TODO: Provide other markup for your page here. -->
<div>
	<?php
		esc_html_e( 'Insert here your custom HTML', PN_TEXTDOMAIN );
	?>
</div>
