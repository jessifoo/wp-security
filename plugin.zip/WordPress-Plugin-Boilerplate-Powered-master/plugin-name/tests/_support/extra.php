<?php

use tad\FunctionMocker\FunctionMocker;
FunctionMocker::init();

//WPBPGen{{#if libraries_wpbp__widgets-helper}}
class WPH_Widget {

	public $id_base;

	function create_widget( $args ) {

	}

	function form( $instance ) {

	}

	function update( $new_instance, $old_instance ) {

	}

	function _register() {

	}

}
//{{/if}}
